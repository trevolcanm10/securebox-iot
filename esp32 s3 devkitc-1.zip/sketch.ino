/*
  ============================================================
  SECUREBOX IoT
  Sistema inteligente de control y monitoreo de acceso
  Placa: ESP32-S3 DevKitC-1
  Plataforma: Wokwi
  ============================================================

  FUNCIONES IMPLEMENTADAS:
  - Autenticación mediante RFID RC522
  - Apertura y cierre automático mediante servomotor
  - Monitoreo de dos compartimientos con HC-SR04
  - Detección de movimiento mediante PIR
  - Alertas mediante LED rojo y buzzer
  - Indicador de acceso autorizado mediante LED verde
  - Visualización en OLED SSD1306
  - Conexión Wi-Fi Wokwi-GUEST
  - Publicación de eventos mediante MQTT
  - Operación local aunque falle Internet o MQTT
*/

#include <WiFi.h>
#include <PubSubClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>

// ============================================================
// CONFIGURACIÓN GENERAL
// ============================================================

const char *DEVICE_ID = "box01";

// Red Wi-Fi predeterminada de Wokwi
const char *WIFI_SSID = "Wokwi-GUEST";
const char *WIFI_PASSWORD = "";

// Broker MQTT público para pruebas
const char *MQTT_SERVER = "broker.hivemq.com";
const uint16_t MQTT_PORT = 1883;

// Raíz de tópicos MQTT
const char *MQTT_ROOT = "securebox/unmsm/grupo01/box01";

// ============================================================
// ASIGNACIÓN DE PINES
// ============================================================

// I2C OLED
const uint8_t OLED_SDA_PIN = 8;
const uint8_t OLED_SCL_PIN = 9;

// RFID RC522 - SPI
const uint8_t RFID_SS_PIN = 10;
const uint8_t RFID_MOSI_PIN = 11;
const uint8_t RFID_SCK_PIN = 12;
const uint8_t RFID_MISO_PIN = 13;
const uint8_t RFID_RST_PIN = 14;

// Actuadores
const uint8_t SERVO_PIN = 4;
const uint8_t LED_GREEN_PIN = 17;
const uint8_t LED_RED_PIN = 18;
const uint8_t BUZZER_PIN = 21;

// Sensor PIR
const uint8_t PIR_PIN = 5;

// Sensor ultrasónico 1
const uint8_t TRIG_1_PIN = 6;
const uint8_t ECHO_1_PIN = 7;

// Sensor ultrasónico 2
const uint8_t TRIG_2_PIN = 15;
const uint8_t ECHO_2_PIN = 16;

// ============================================================
// CONFIGURACIÓN OLED
// ============================================================

const uint8_t SCREEN_WIDTH = 128;
const uint8_t SCREEN_HEIGHT = 64;
const int8_t OLED_RESET = -1;
const uint8_t OLED_ADDRESS = 0x3C;

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  OLED_RESET
);

// ============================================================
// CONFIGURACIÓN RFID
// ============================================================

MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);

/*
  Tarjetas autorizadas en Wokwi:

  Tarjeta azul:
  01:02:03:04

  Tarjeta verde:
  11:22:33:44

  Las demás tarjetas serán rechazadas.
*/

const char *AUTHORIZED_UIDS[] = {
  "01:02:03:04",
  "11:22:33:44"
};

const size_t AUTHORIZED_UID_COUNT =
  sizeof(AUTHORIZED_UIDS) / sizeof(AUTHORIZED_UIDS[0]);

// ============================================================
// CONFIGURACIÓN SERVO
// ============================================================

Servo lockServo;

const int SERVO_LOCKED_ANGLE = 0;
const int SERVO_OPEN_ANGLE = 90;

// Tiempo que la caja permanece abierta
const unsigned long DOOR_OPEN_TIME_MS = 8000;

// ============================================================
// CONFIGURACIÓN ULTRASÓNICOS
// ============================================================

// Si la distancia es menor o igual al umbral,
// se considera que existe un objeto.
const float OCCUPANCY_THRESHOLD_CM = 15.0;

// Intervalo de lectura
const unsigned long SENSOR_READ_INTERVAL_MS = 1000;

// ============================================================
// CONFIGURACIÓN DE ALARMAS
// ============================================================

const unsigned long ACCESS_DENIED_ALARM_MS = 2500;
const unsigned long SECURITY_ALARM_MS = 5000;
const unsigned long PIR_GRACE_PERIOD_MS = 2500;

// ============================================================
// OBJETOS DE RED
// ============================================================

WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

// ============================================================
// ESTADOS DEL SISTEMA
// ============================================================

enum SystemState {
  STATE_INITIALIZING,
  STATE_LOCKED,
  STATE_VALIDATING,
  STATE_AUTHORIZED,
  STATE_OPEN,
  STATE_DENIED,
  STATE_ALARM,
  STATE_OFFLINE
};

SystemState currentState = STATE_INITIALIZING;

bool doorOpen = false;
bool alarmActive = false;
bool authorizedSession = false;

bool compartment1Occupied = false;
bool compartment2Occupied = false;

bool previousCompartment1Occupied = false;
bool previousCompartment2Occupied = false;

bool pirCurrentState = false;
bool pirPreviousState = false;

float compartment1Distance = 0.0;
float compartment2Distance = 0.0;

String lastUID = "";
String lastEvent = "Inicializando";

unsigned long doorOpenedAt = 0;
unsigned long alarmStartedAt = 0;
unsigned long alarmDuration = 0;
unsigned long lastDoorClosedAt = 0;

unsigned long lastSensorReadAt = 0;
unsigned long lastDisplayUpdateAt = 0;
unsigned long lastWiFiAttemptAt = 0;
unsigned long lastMQTTAttemptAt = 0;

// ============================================================
// DECLARACIÓN DE FUNCIONES
// ============================================================

void configurePins();
void initializeOLED();
void initializeRFID();
void initializeServo();

void connectWiFi();
void maintainWiFiConnection();
void connectMQTT();
void maintainMQTTConnection();

void publishMQTT(
  const String &topicSuffix,
  const String &payload,
  bool retained = false
);

void publishSystemStatus();
void publishAccessEvent(
  const String &eventType,
  const String &uid
);

void publishCompartmentState(
  int compartment,
  bool occupied,
  float distance
);

void publishDoorState();
void publishAlarmState(const String &reason);

String buildTopic(const String &suffix);
String boolToOccupation(bool occupied);
String systemStateToString(SystemState state);

void processRFID();
String getRFIDUID();
bool isAuthorizedUID(const String &uid);

void authorizeAccess(const String &uid);
void denyAccess(const String &uid);

void openDoor();
void closeDoor();

float readUltrasonicDistance(
  uint8_t triggerPin,
  uint8_t echoPin
);

void updateCompartments();
void processPIR();

void activateAlarm(
  const String &reason,
  unsigned long durationMs
);

void deactivateAlarm();

void updateTimedEvents();
void updateOLED();
void showStartupScreen();

void printSystemSummary();

// ============================================================
// SETUP
// ============================================================

void setup() {
  Serial.begin(115200);

  delay(300);

  Serial.println();
  Serial.println("======================================");
  Serial.println("       SECUREBOX IoT - INICIO");
  Serial.println("======================================");

  configurePins();
  initializeOLED();
  initializeServo();
  initializeRFID();

  showStartupScreen();

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setBufferSize(1024);
  mqttClient.setKeepAlive(30);

  connectWiFi();

  if (WiFi.status() == WL_CONNECTED) {
    connectMQTT();
  }

  // Primera lectura de los compartimientos
  compartment1Distance =
    readUltrasonicDistance(TRIG_1_PIN, ECHO_1_PIN);

  delay(60);

  compartment2Distance =
    readUltrasonicDistance(TRIG_2_PIN, ECHO_2_PIN);

  compartment1Occupied =
    compartment1Distance <= OCCUPANCY_THRESHOLD_CM;

  compartment2Occupied =
    compartment2Distance <= OCCUPANCY_THRESHOLD_CM;

  previousCompartment1Occupied = compartment1Occupied;
  previousCompartment2Occupied = compartment2Occupied;

  currentState = STATE_LOCKED;
  lastEvent = "Sistema preparado";

  publishSystemStatus();
  publishDoorState();

  publishCompartmentState(
    1,
    compartment1Occupied,
    compartment1Distance
  );

  publishCompartmentState(
    2,
    compartment2Occupied,
    compartment2Distance
  );

  printSystemSummary();
  updateOLED();
}

// ============================================================
// LOOP PRINCIPAL
// ============================================================

void loop() {
  maintainWiFiConnection();
  maintainMQTTConnection();

  if (mqttClient.connected()) {
    mqttClient.loop();
  }

  processRFID();
  processPIR();
  updateCompartments();
  updateTimedEvents();

  if (millis() - lastDisplayUpdateAt >= 400) {
    lastDisplayUpdateAt = millis();
    updateOLED();
  }

  delay(10);
}

// ============================================================
// CONFIGURACIÓN DE HARDWARE
// ============================================================

void configurePins() {
  pinMode(LED_GREEN_PIN, OUTPUT);
  pinMode(LED_RED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  pinMode(PIR_PIN, INPUT);

  pinMode(TRIG_1_PIN, OUTPUT);
  pinMode(ECHO_1_PIN, INPUT);

  pinMode(TRIG_2_PIN, OUTPUT);
  pinMode(ECHO_2_PIN, INPUT);

  digitalWrite(LED_GREEN_PIN, LOW);
  digitalWrite(LED_RED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  digitalWrite(TRIG_1_PIN, LOW);
  digitalWrite(TRIG_2_PIN, LOW);
}

void initializeOLED() {
  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);

  if (!display.begin(
        SSD1306_SWITCHCAPVCC,
        OLED_ADDRESS
      )) {
    Serial.println(
      "[ERROR] No se pudo inicializar la pantalla OLED"
    );

    while (true) {
      digitalWrite(LED_RED_PIN, HIGH);
      delay(250);
      digitalWrite(LED_RED_PIN, LOW);
      delay(250);
    }
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.display();

  Serial.println("[OK] Pantalla OLED inicializada");
}

void initializeRFID() {
  SPI.begin(
    RFID_SCK_PIN,
    RFID_MISO_PIN,
    RFID_MOSI_PIN,
    RFID_SS_PIN
  );

  rfid.PCD_Init();

  delay(100);

  Serial.println("[OK] RFID RC522 inicializado");
  rfid.PCD_DumpVersionToSerial();
}

void initializeServo() {
  lockServo.setPeriodHertz(50);

  lockServo.attach(
    SERVO_PIN,
    500,
    2400
  );

  lockServo.write(SERVO_LOCKED_ANGLE);

  doorOpen = false;

  Serial.println("[OK] Servomotor inicializado");
}

// ============================================================
// WI-FI
// ============================================================

void connectWiFi() {
  Serial.println();
  Serial.print("[WIFI] Conectando a ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long connectionStartedAt = millis();

  while (
    WiFi.status() != WL_CONNECTED &&
    millis() - connectionStartedAt < 12000
  ) {
    Serial.print(".");
    delay(400);
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("[WIFI] Conexión establecida");
    Serial.print("[WIFI] Dirección IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(
      "[WIFI] Sin conexión. El sistema continuará localmente."
    );

    currentState = STATE_OFFLINE;
  }
}

void maintainWiFiConnection() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  if (millis() - lastWiFiAttemptAt < 10000) {
    return;
  }

  lastWiFiAttemptAt = millis();

  Serial.println("[WIFI] Intentando reconexión...");

  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

// ============================================================
// MQTT
// ============================================================

void connectMQTT() {
  if (WiFi.status() != WL_CONNECTED) {
    return;
  }

  if (mqttClient.connected()) {
    return;
  }

  uint64_t chipId = ESP.getEfuseMac();

  String clientId =
    "SecureBox-" +
    String(DEVICE_ID) +
    "-" +
    String(
      static_cast<uint32_t>(chipId),
      HEX
    );

  Serial.print("[MQTT] Conectando al broker ");
  Serial.println(MQTT_SERVER);

  bool connected = mqttClient.connect(
    clientId.c_str(),
    buildTopic("status").c_str(),
    1,
    true,
    "offline"
  );

  if (connected) {
    Serial.println("[MQTT] Conexión establecida");

    publishMQTT(
      "status",
      "online",
      true
    );

    publishSystemStatus();
    publishDoorState();

    publishCompartmentState(
      1,
      compartment1Occupied,
      compartment1Distance
    );

    publishCompartmentState(
      2,
      compartment2Occupied,
      compartment2Distance
    );
  } else {
    Serial.print("[MQTT] Error de conexión. Código: ");
    Serial.println(mqttClient.state());
  }
}

void maintainMQTTConnection() {
  if (WiFi.status() != WL_CONNECTED) {
    return;
  }

  if (mqttClient.connected()) {
    return;
  }

  if (millis() - lastMQTTAttemptAt < 5000) {
    return;
  }

  lastMQTTAttemptAt = millis();
  connectMQTT();
}

String buildTopic(const String &suffix) {
  return String(MQTT_ROOT) + "/" + suffix;
}

void publishMQTT(
  const String &topicSuffix,
  const String &payload,
  bool retained
) {
  if (!mqttClient.connected()) {
    Serial.print("[MQTT OFFLINE] ");
    Serial.print(topicSuffix);
    Serial.print(" -> ");
    Serial.println(payload);
    return;
  }

  String completeTopic = buildTopic(topicSuffix);

  bool success = mqttClient.publish(
    completeTopic.c_str(),
    payload.c_str(),
    retained
  );

  Serial.print("[MQTT] ");
  Serial.print(completeTopic);
  Serial.print(" -> ");
  Serial.print(payload);

  if (success) {
    Serial.println(" [OK]");
  } else {
    Serial.println(" [ERROR]");
  }
}

void publishSystemStatus() {
  String payload = "{";
  payload += "\"deviceId\":\"";
  payload += DEVICE_ID;
  payload += "\",";
  payload += "\"eventType\":\"SYSTEM_STATUS\",";
  payload += "\"state\":\"";
  payload += systemStateToString(currentState);
  payload += "\",";
  payload += "\"wifiConnected\":";
  payload += (
    WiFi.status() == WL_CONNECTED
      ? "true"
      : "false"
  );
  payload += ",";
  payload += "\"mqttConnected\":";
  payload += (
    mqttClient.connected()
      ? "true"
      : "false"
  );
  payload += ",";
  payload += "\"uptimeMs\":";
  payload += String(millis());
  payload += "}";

  publishMQTT(
    "system/state",
    payload,
    true
  );
}

void publishAccessEvent(
  const String &eventType,
  const String &uid
) {
  String payload = "{";
  payload += "\"deviceId\":\"";
  payload += DEVICE_ID;
  payload += "\",";
  payload += "\"eventType\":\"";
  payload += eventType;
  payload += "\",";
  payload += "\"uid\":\"";
  payload += uid;
  payload += "\",";
  payload += "\"doorState\":\"";
  payload += doorOpen ? "OPEN" : "CLOSED";
  payload += "\",";
  payload += "\"alarmState\":\"";
  payload += alarmActive ? "ACTIVE" : "INACTIVE";
  payload += "\",";
  payload += "\"uptimeMs\":";
  payload += String(millis());
  payload += "}";

  publishMQTT(
    "access/event",
    payload,
    false
  );
}

void publishCompartmentState(
  int compartment,
  bool occupied,
  float distance
) {
  String payload = "{";
  payload += "\"deviceId\":\"";
  payload += DEVICE_ID;
  payload += "\",";
  payload += "\"eventType\":\"COMPARTMENT_STATE\",";
  payload += "\"compartment\":";
  payload += String(compartment);
  payload += ",";
  payload += "\"state\":\"";
  payload += occupied ? "OCCUPIED" : "EMPTY";
  payload += "\",";
  payload += "\"distanceCm\":";
  payload += String(distance, 1);
  payload += ",";
  payload += "\"uptimeMs\":";
  payload += String(millis());
  payload += "}";

  String baseTopic =
    "compartment/" +
    String(compartment);

  publishMQTT(
    baseTopic + "/event",
    payload,
    false
  );

  publishMQTT(
    baseTopic + "/state",
    occupied ? "occupied" : "empty",
    true
  );

  publishMQTT(
    baseTopic + "/distance",
    String(distance, 1),
    true
  );
}

void publishDoorState() {
  publishMQTT(
    "door/state",
    doorOpen ? "open" : "closed",
    true
  );
}

void publishAlarmState(const String &reason) {
  String payload = "{";
  payload += "\"deviceId\":\"";
  payload += DEVICE_ID;
  payload += "\",";
  payload += "\"eventType\":\"ALARM_STATE\",";
  payload += "\"state\":\"";
  payload += alarmActive ? "ACTIVE" : "INACTIVE";
  payload += "\",";
  payload += "\"reason\":\"";
  payload += reason;
  payload += "\",";
  payload += "\"uptimeMs\":";
  payload += String(millis());
  payload += "}";

  publishMQTT(
    "alarm/event",
    payload,
    false
  );

  publishMQTT(
    "alarm/state",
    alarmActive ? "active" : "inactive",
    true
  );
}

// ============================================================
// RFID Y AUTENTICACIÓN
// ============================================================

void processRFID() {
  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }

  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }

  currentState = STATE_VALIDATING;

  String uid = getRFIDUID();

  lastUID = uid;

  Serial.println();
  Serial.print("[RFID] Tarjeta detectada: ");
  Serial.println(uid);

  if (isAuthorizedUID(uid)) {
    authorizeAccess(uid);
  } else {
    denyAccess(uid);
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}

String getRFIDUID() {
  String uid = "";

  for (byte index = 0; index < rfid.uid.size; index++) {
    if (index > 0) {
      uid += ":";
    }

    if (rfid.uid.uidByte[index] < 0x10) {
      uid += "0";
    }

    uid += String(
      rfid.uid.uidByte[index],
      HEX
    );
  }

  uid.toUpperCase();

  return uid;
}

bool isAuthorizedUID(const String &uid) {
  for (
    size_t index = 0;
    index < AUTHORIZED_UID_COUNT;
    index++
  ) {
    if (uid.equalsIgnoreCase(AUTHORIZED_UIDS[index])) {
      return true;
    }
  }

  return false;
}

void authorizeAccess(const String &uid) {
  Serial.println("[ACCESO] Usuario autorizado");

  lastEvent = "Acceso autorizado";
  currentState = STATE_AUTHORIZED;
  authorizedSession = true;

  digitalWrite(LED_GREEN_PIN, HIGH);
  digitalWrite(LED_RED_PIN, LOW);

  deactivateAlarm();

  publishAccessEvent(
    "ACCESS_AUTHORIZED",
    uid
  );

  openDoor();
}

void denyAccess(const String &uid) {
  Serial.println("[ACCESO] Usuario no autorizado");

  lastEvent = "Acceso denegado";
  currentState = STATE_DENIED;
  authorizedSession = false;

  publishAccessEvent(
    "ACCESS_DENIED",
    uid
  );

  activateAlarm(
    "ACCESS_DENIED",
    ACCESS_DENIED_ALARM_MS
  );
}

// ============================================================
// CONTROL DE LA CERRADURA
// ============================================================

void openDoor() {
  if (doorOpen) {
    return;
  }

  Serial.println("[PUERTA] Desbloqueando caja...");

  lockServo.write(SERVO_OPEN_ANGLE);

  doorOpen = true;
  doorOpenedAt = millis();
  currentState = STATE_OPEN;
  lastEvent = "Caja abierta";

  publishDoorState();

  publishMQTT(
    "door/event",
    "{\"eventType\":\"DOOR_OPENED\"}",
    false
  );
}

void closeDoor() {
  if (!doorOpen) {
    return;
  }

  Serial.println("[PUERTA] Bloqueando caja...");

  lockServo.write(SERVO_LOCKED_ANGLE);

  doorOpen = false;
  authorizedSession = false;
  lastDoorClosedAt = millis();

  digitalWrite(LED_GREEN_PIN, LOW);

  currentState = STATE_LOCKED;
  lastEvent = "Caja cerrada";

  publishDoorState();

  publishMQTT(
    "door/event",
    "{\"eventType\":\"DOOR_CLOSED\"}",
    false
  );

  // Registrar el estado final de los compartimientos
  publishCompartmentState(
    1,
    compartment1Occupied,
    compartment1Distance
  );

  publishCompartmentState(
    2,
    compartment2Occupied,
    compartment2Distance
  );
}

// ============================================================
// SENSORES ULTRASÓNICOS
// ============================================================

float readUltrasonicDistance(
  uint8_t triggerPin,
  uint8_t echoPin
) {
  digitalWrite(triggerPin, LOW);
  delayMicroseconds(3);

  digitalWrite(triggerPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(triggerPin, LOW);

  unsigned long duration = pulseIn(
    echoPin,
    HIGH,
    30000
  );

  if (duration == 0) {
    return 400.0;
  }

  return duration / 58.0;
}

void updateCompartments() {
  if (
    millis() - lastSensorReadAt <
    SENSOR_READ_INTERVAL_MS
  ) {
    return;
  }

  lastSensorReadAt = millis();

  compartment1Distance =
    readUltrasonicDistance(
      TRIG_1_PIN,
      ECHO_1_PIN
    );

  /*
    La espera entre sensores reduce el riesgo de que
    los pulsos ultrasónicos se interfieran.
  */
  delay(60);

  compartment2Distance =
    readUltrasonicDistance(
      TRIG_2_PIN,
      ECHO_2_PIN
    );

  compartment1Occupied =
    compartment1Distance <=
    OCCUPANCY_THRESHOLD_CM;

  compartment2Occupied =
    compartment2Distance <=
    OCCUPANCY_THRESHOLD_CM;

  if (
    compartment1Occupied !=
    previousCompartment1Occupied
  ) {
    Serial.print("[COMPARTIMIENTO 1] ");
    Serial.println(
      boolToOccupation(compartment1Occupied)
    );

    lastEvent = compartment1Occupied
      ? "Objeto colocado C1"
      : "Objeto retirado C1";

    publishCompartmentState(
      1,
      compartment1Occupied,
      compartment1Distance
    );

    previousCompartment1Occupied =
      compartment1Occupied;
  }

  if (
    compartment2Occupied !=
    previousCompartment2Occupied
  ) {
    Serial.print("[COMPARTIMIENTO 2] ");
    Serial.println(
      boolToOccupation(compartment2Occupied)
    );

    lastEvent = compartment2Occupied
      ? "Objeto colocado C2"
      : "Objeto retirado C2";

    publishCompartmentState(
      2,
      compartment2Occupied,
      compartment2Distance
    );

    previousCompartment2Occupied =
      compartment2Occupied;
  }
}

// ============================================================
// SENSOR PIR
// ============================================================

void processPIR() {
  pirCurrentState = digitalRead(PIR_PIN) == HIGH;

  /*
    Se procesa únicamente el flanco de subida para
    evitar publicar repetidamente el mismo movimiento.
  */
  bool risingEdge =
    pirCurrentState &&
    !pirPreviousState;

  pirPreviousState = pirCurrentState;

  if (!risingEdge) {
    return;
  }

  Serial.println("[PIR] Movimiento detectado");

  publishMQTT(
    "motion/state",
    "detected",
    false
  );

  /*
    No se genera alarma si:
    - La caja está abierta por un usuario autorizado.
    - Existe una sesión autorizada.
    - La caja acaba de cerrarse y está dentro del
      periodo de gracia.
  */

  bool gracePeriodActive =
    millis() - lastDoorClosedAt <
    PIR_GRACE_PERIOD_MS;

  if (
    doorOpen ||
    authorizedSession ||
    gracePeriodActive
  ) {
    Serial.println(
      "[PIR] Movimiento permitido durante sesión autorizada"
    );

    publishMQTT(
      "motion/event",
      "{\"eventType\":\"AUTHORIZED_MOTION\"}",
      false
    );

    return;
  }

  activateAlarm(
    "UNAUTHORIZED_MOTION",
    SECURITY_ALARM_MS
  );

  publishMQTT(
    "motion/event",
    "{\"eventType\":\"UNAUTHORIZED_MOTION\"}",
    false
  );
}

// ============================================================
// ALARMA
// ============================================================

void activateAlarm(
  const String &reason,
  unsigned long durationMs
) {
  alarmActive = true;
  alarmStartedAt = millis();
  alarmDuration = durationMs;

  currentState = STATE_ALARM;
  lastEvent = "Alarma: " + reason;

  digitalWrite(LED_GREEN_PIN, LOW);
  digitalWrite(LED_RED_PIN, HIGH);

  tone(
    BUZZER_PIN,
    1200
  );

  Serial.print("[ALARMA] Activada: ");
  Serial.println(reason);

  publishAlarmState(reason);
}

void deactivateAlarm() {
  if (!alarmActive) {
    digitalWrite(LED_RED_PIN, LOW);
    noTone(BUZZER_PIN);
    return;
  }

  alarmActive = false;

  digitalWrite(LED_RED_PIN, LOW);
  noTone(BUZZER_PIN);

  Serial.println("[ALARMA] Desactivada");

  publishAlarmState("ALARM_FINISHED");

  if (doorOpen) {
    currentState = STATE_OPEN;
  } else {
    currentState = STATE_LOCKED;
  }
}

// ============================================================
// EVENTOS TEMPORIZADOS
// ============================================================

void updateTimedEvents() {
  if (
    doorOpen &&
    millis() - doorOpenedAt >= DOOR_OPEN_TIME_MS
  ) {
    closeDoor();
  }

  if (
    alarmActive &&
    millis() - alarmStartedAt >= alarmDuration
  ) {
    deactivateAlarm();

    if (!doorOpen) {
      currentState = STATE_LOCKED;
      lastEvent = "Sistema bloqueado";
    }
  }
}

// ============================================================
// PANTALLA OLED
// ============================================================

void showStartupScreen() {
  display.clearDisplay();

  display.setTextSize(2);
  display.setCursor(5, 5);
  display.println("SecureBox");

  display.setTextSize(1);
  display.setCursor(18, 32);
  display.println("IoT Security");

  display.setCursor(15, 48);
  display.println("Inicializando...");

  display.display();

  delay(1200);
}

void updateOLED() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("SECUREBOX IoT");

  display.drawLine(
    0,
    10,
    127,
    10,
    SSD1306_WHITE
  );

  display.setCursor(0, 14);
  display.print("Caja: ");
  display.println(
    doorOpen ? "ABIERTA" : "CERRADA"
  );

  display.setCursor(0, 25);
  display.print("C1: ");
  display.print(
    compartment1Occupied ? "OCUPADO" : "VACIO"
  );
  display.print(" ");
  display.print(compartment1Distance, 0);
  display.println("cm");

  display.setCursor(0, 36);
  display.print("C2: ");
  display.print(
    compartment2Occupied ? "OCUPADO" : "VACIO"
  );
  display.print(" ");
  display.print(compartment2Distance, 0);
  display.println("cm");

  display.setCursor(0, 47);

  if (alarmActive) {
    display.println("ALERTA ACTIVA");
  } else if (WiFi.status() == WL_CONNECTED) {
    display.println("WiFi: CONECTADO");
  } else {
    display.println("WiFi: OFFLINE");
  }

  display.setCursor(0, 57);

  String shortEvent = lastEvent;

  if (shortEvent.length() > 21) {
    shortEvent = shortEvent.substring(0, 21);
  }

  display.println(shortEvent);

  display.display();
}

// ============================================================
// UTILIDADES
// ============================================================

String boolToOccupation(bool occupied) {
  return occupied ? "OCUPADO" : "VACÍO";
}

String systemStateToString(SystemState state) {
  switch (state) {
    case STATE_INITIALIZING:
      return "INITIALIZING";

    case STATE_LOCKED:
      return "LOCKED";

    case STATE_VALIDATING:
      return "VALIDATING";

    case STATE_AUTHORIZED:
      return "AUTHORIZED";

    case STATE_OPEN:
      return "OPEN";

    case STATE_DENIED:
      return "DENIED";

    case STATE_ALARM:
      return "ALARM";

    case STATE_OFFLINE:
      return "OFFLINE";

    default:
      return "UNKNOWN";
  }
}

void printSystemSummary() {
  Serial.println();
  Serial.println("======================================");
  Serial.println("      SECUREBOX IoT PREPARADO");
  Serial.println("======================================");

  Serial.print("Compartimiento 1: ");
  Serial.print(
    boolToOccupation(compartment1Occupied)
  );
  Serial.print(" - ");
  Serial.print(compartment1Distance, 1);
  Serial.println(" cm");

  Serial.print("Compartimiento 2: ");
  Serial.print(
    boolToOccupation(compartment2Occupied)
  );
  Serial.print(" - ");
  Serial.print(compartment2Distance, 1);
  Serial.println(" cm");

  Serial.println();
  Serial.println("TARJETAS AUTORIZADAS:");
  Serial.println("- Azul:  01:02:03:04");
  Serial.println("- Verde: 11:22:33:44");

  Serial.println();
  Serial.println("TARJETAS DENEGADAS:");
  Serial.println("- Amarilla: 55:66:77:88");
  Serial.println("- Roja:      AA:BB:CC:DD");
  Serial.println("- Llavero:   C0:FF:EE:99");

  Serial.println();
  Serial.println("Esperando tarjeta RFID...");
  Serial.println("======================================");
}